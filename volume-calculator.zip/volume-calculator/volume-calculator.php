<?php
/*
Plugin Name: Volume Calculator
Description: A simple volume calculator plugin.
Version: 1.0
Author: Your Name
*/

// Enqueue necessary scripts and styles
function volume_calculator_enqueue_scripts() {
    wp_enqueue_script('volume-calculator-script', plugins_url('script.js', __FILE__), array('jquery'), '1.0', true);
    wp_enqueue_style('volume-calculator-style', plugins_url('style.css', __FILE__), array(), '1.0');
}
add_action('wp_enqueue_scripts', 'volume_calculator_enqueue_scripts');

// Add the calculator HTML form
function volume_calculator_form() {
    ob_start();
    include(plugin_dir_path(__FILE__) . 'form.php');
    return ob_get_clean();
}
add_shortcode('volume_calculator', 'volume_calculator_form');
?>
