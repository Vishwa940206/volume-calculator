<div id="volume-calculator"> 
    <label for="width" class="label">Width (mm):</label>
    <input class="text" type="number" id="width" step="any" required style="border-radius: 24px;">
    
    <label for="height" class="label">Height (mm):</label>
    <input class="text" type="number" id="height" step="any" required style="border-radius: 24px;">
    
    <label for="depth" class="label">Depth (mm):</label>
    <input class="text" type="number" id="depth" step="any" required style="border-radius: 24px;">
    
    <label for="unit" class="label">Unit:</label><br>
    <select id="unit" class="text" style="width:100%;">
        <option value="10">Centimeters</option>
        <option value="1000">Meters</option>
        <option value="1">Millimeters</option>
        <option value="25.4">Inches</option>
        <option value="304.8">Feet</option>
    </select>
    <br> 
    
    <button class="button" id="calculate-button">Calculate</button>
    
    <div id="result-box"></div>
</div>