jQuery(document).ready(function($) {
    $('#calculate-button').click(function() {
        var width = parseFloat($('#width').val()) || 0; // Set to 0 if not provided
        var height = parseFloat($('#height').val()) || 0; // Set to 0 if not provided
        var depth = parseFloat($('#depth').val()) || 0; // Set to 0 if not provided
        var unit = parseFloat($('#unit').val()) || 1; // Set to 1 (millimeters) if not provided
        
        var volume = (width * height * depth) / (unit * unit * unit);
        
        if (!isNaN(volume)) {
            $('#result-box').text('Volume: ' + volume.toFixed(2) + ' cubic ' + $('#unit option:selected').text());
        } else {
            $('#result-box').text('Please enter valid dimensions.');
        }
    });
});
